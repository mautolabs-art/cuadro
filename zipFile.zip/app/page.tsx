'use client'

import { useState, useEffect } from 'react'
import OnboardingFlow from '@/components/onboarding/OnboardingFlow'
import Dashboard from '@/components/dashboard/Dashboard'
import ChatInterface from '@/components/chat/ChatInterface'

interface FixedExpense {
  id: string
  name: string
  icon?: string
  amount: number
  selected?: boolean
  paid: boolean
}

interface VariableExpense {
  id: string
  description: string
  amount: number
  category: string
  date: Date
}

interface UserData {
  income: number
  fixedExpenses: FixedExpense[]
  variableExpenses: VariableExpense[]
  onboardingComplete: boolean
}

// Local storage key
const STORAGE_KEY = 'cuadro_user_data'

export default function Home() {
  const [userData, setUserData] = useState<UserData | null>(null)
  const [currentView, setCurrentView] = useState<'onboarding' | 'dashboard' | 'chat'>('onboarding')
  const [isLoading, setIsLoading] = useState(true)

  // Load data from localStorage on mount
  useEffect(() => {
    const savedData = localStorage.getItem(STORAGE_KEY)
    if (savedData) {
      const parsed = JSON.parse(savedData)
      // Convert date strings back to Date objects
      if (parsed.variableExpenses) {
        parsed.variableExpenses = parsed.variableExpenses.map((exp: any) => ({
          ...exp,
          date: new Date(exp.date)
        }))
      }
      setUserData(parsed)
      setCurrentView(parsed.onboardingComplete ? 'dashboard' : 'onboarding')
    }
    setIsLoading(false)

    // Register service worker
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js')
        .then((registration) => {
          console.log('SW registered:', registration)
        })
        .catch((error) => {
          console.log('SW registration failed:', error)
        })
    }
  }, [])

  // Save data to localStorage whenever it changes
  useEffect(() => {
    if (userData) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(userData))
    }
  }, [userData])

  // Handle onboarding completion
  const handleOnboardingComplete = (data: { income: number; fixedExpenses: any[] }) => {
    const newUserData: UserData = {
      income: data.income,
      fixedExpenses: data.fixedExpenses.map(exp => ({
        ...exp,
        paid: false
      })),
      variableExpenses: [],
      onboardingComplete: true
    }
    setUserData(newUserData)
    setCurrentView('dashboard')
  }

  // Toggle fixed expense paid status
  const handleTogglePaid = (id: string) => {
    if (!userData) return

    setUserData(prev => {
      if (!prev) return prev
      return {
        ...prev,
        fixedExpenses: prev.fixedExpenses.map(exp =>
          exp.id === id ? { ...exp, paid: !exp.paid } : exp
        )
      }
    })
  }

  // Handle chat message (connects to n8n webhook later)
  const handleSendMessage = async (message: string): Promise<string> => {
    // Parse expense from message (simple pattern: "description amount")
    const expensePattern = /(.+?)\s+(\d+(?:\.\d+)?)/
    const match = message.match(expensePattern)

    if (match) {
      const description = match[1].trim()
      const amount = parseInt(match[2])

      // Add variable expense
      const newExpense: VariableExpense = {
        id: Date.now().toString(),
        description,
        amount,
        category: categorizeExpense(description),
        date: new Date()
      }

      setUserData(prev => {
        if (!prev) return prev
        return {
          ...prev,
          variableExpenses: [...prev.variableExpenses, newExpense]
        }
      })

      // Calculate new available amount
      const totalFixed = userData?.fixedExpenses.reduce((sum, exp) => sum + exp.amount, 0) || 0
      const totalVariable = (userData?.variableExpenses.reduce((sum, exp) => sum + exp.amount, 0) || 0) + amount
      const available = (userData?.income || 0) - totalFixed - totalVariable

      return `✅ Listo, ${description} por $${amount.toLocaleString('es-CO')}\n\n📊 Te quedan $${available.toLocaleString('es-CO')} pa'l mes.`
    }

    // Handle other queries
    if (message.toLowerCase().includes('gastado') || message.toLowerCase().includes('cuanto') || message.toLowerCase().includes('llevo')) {
      const totalVariable = userData?.variableExpenses.reduce((sum, exp) => sum + exp.amount, 0) || 0
      const categories = getCategorySummary()

      let response = `📊 Este mes llevas $${totalVariable.toLocaleString('es-CO')} en gasticos variables.\n\n`

      if (categories.length > 0) {
        response += 'Así va la cosa:\n'
        categories.forEach(cat => {
          response += `• ${cat.name}: $${cat.total.toLocaleString('es-CO')}\n`
        })
      }

      return response
    }

    return 'Epa, no te entendí. Escríbeme algo como "Almuerzo 15000" o pregúntame "¿cuánto llevo?"'
  }

  // Simple expense categorization
  const categorizeExpense = (description: string): string => {
    const lower = description.toLowerCase()
    if (lower.includes('almuerzo') || lower.includes('comida') || lower.includes('restaurante') || lower.includes('café') || lower.includes('tintico') || lower.includes('desayuno') || lower.includes('cena')) {
      return 'Alimentación'
    }
    if (lower.includes('uber') || lower.includes('taxi') || lower.includes('bus') || lower.includes('transporte') || lower.includes('gasolina') || lower.includes('parqueadero')) {
      return 'Transporte'
    }
    if (lower.includes('mercado') || lower.includes('supermercado') || lower.includes('exito') || lower.includes('d1') || lower.includes('ara')) {
      return 'Mercado'
    }
    if (lower.includes('cerveza') || lower.includes('trago') || lower.includes('rumba') || lower.includes('bar')) {
      return 'Rumba'
    }
    return 'Otros'
  }

  // Get category summary
  const getCategorySummary = () => {
    if (!userData?.variableExpenses) return []

    const categories: { [key: string]: number } = {}
    userData.variableExpenses.forEach(exp => {
      categories[exp.category] = (categories[exp.category] || 0) + exp.amount
    })

    return Object.entries(categories)
      .map(([name, total]) => ({ name, total }))
      .sort((a, b) => b.total - a.total)
  }

  // Calculate available money
  const getAvailableMoney = () => {
    if (!userData) return 0
    const totalFixed = userData.fixedExpenses.reduce((sum, exp) => sum + exp.amount, 0)
    const totalVariable = userData.variableExpenses.reduce((sum, exp) => sum + exp.amount, 0)
    return userData.income - totalFixed - totalVariable
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-primary text-xl">Cargando...</div>
      </div>
    )
  }

  return (
    <main className="min-h-screen bg-background">
      {currentView === 'onboarding' && (
        <OnboardingFlow onComplete={handleOnboardingComplete} />
      )}

      {currentView === 'dashboard' && userData && (
        <Dashboard
          income={userData.income}
          fixedExpenses={userData.fixedExpenses}
          variableExpenses={userData.variableExpenses}
          onTogglePaid={handleTogglePaid}
          onOpenChat={() => setCurrentView('chat')}
        />
      )}

      {currentView === 'chat' && userData && (
        <ChatInterface
          onBack={() => setCurrentView('dashboard')}
          onSendMessage={handleSendMessage}
          availableMoney={getAvailableMoney()}
        />
      )}
    </main>
  )
}
