'use client'

import { useState } from 'react'
import { Home, Wifi, Tv, Car, CreditCard, Heart, GraduationCap, Smartphone, Plus, X } from 'lucide-react'

interface FixedExpense {
  id: string
  name: string
  icon: string
  amount: number
  selected: boolean
}

interface Props {
  onNext: (expenses: FixedExpense[]) => void
  onBack: () => void
}

const defaultExpenses: FixedExpense[] = [
  { id: 'arriendo', name: 'Arriendo/Hipoteca', icon: 'home', amount: 0, selected: false },
  { id: 'servicios', name: 'Servicios (agua, luz, gas)', icon: 'wifi', amount: 0, selected: false },
  { id: 'internet', name: 'Internet/Celular', icon: 'smartphone', amount: 0, selected: false },
  { id: 'streaming', name: 'Streaming (Netflix, Spotify)', icon: 'tv', amount: 0, selected: false },
  { id: 'transporte', name: 'Transporte/Gasolina', icon: 'car', amount: 0, selected: false },
  { id: 'credito', name: 'Tarjeta de crédito', icon: 'creditcard', amount: 0, selected: false },
  { id: 'salud', name: 'EPS/Medicina prepagada', icon: 'heart', amount: 0, selected: false },
  { id: 'educacion', name: 'Educación/Cursos', icon: 'graduation', amount: 0, selected: false },
]

const iconMap: { [key: string]: React.ReactNode } = {
  home: <Home className="w-5 h-5" />,
  wifi: <Wifi className="w-5 h-5" />,
  smartphone: <Smartphone className="w-5 h-5" />,
  tv: <Tv className="w-5 h-5" />,
  car: <Car className="w-5 h-5" />,
  creditcard: <CreditCard className="w-5 h-5" />,
  heart: <Heart className="w-5 h-5" />,
  graduation: <GraduationCap className="w-5 h-5" />,
  custom: <Plus className="w-5 h-5" />,
}

export default function Step3FixedExpenses({ onNext, onBack }: Props) {
  const [expenses, setExpenses] = useState<FixedExpense[]>(defaultExpenses)
  const [showCustom, setShowCustom] = useState(false)
  const [customName, setCustomName] = useState('')

  const formatMoney = (value: string) => {
    const numbers = value.replace(/\D/g, '')
    return numbers.replace(/\B(?=(\d{3})+(?!\d))/g, '.')
  }

  const toggleExpense = (id: string) => {
    setExpenses(prev =>
      prev.map(exp =>
        exp.id === id ? { ...exp, selected: !exp.selected } : exp
      )
    )
  }

  const updateAmount = (id: string, value: string) => {
    const numericValue = parseInt(value.replace(/\./g, '')) || 0
    setExpenses(prev =>
      prev.map(exp =>
        exp.id === id ? { ...exp, amount: numericValue } : exp
      )
    )
  }

  const addCustomExpense = () => {
    if (customName.trim()) {
      const newExpense: FixedExpense = {
        id: `custom-${Date.now()}`,
        name: customName.trim(),
        icon: 'custom',
        amount: 0,
        selected: true
      }
      setExpenses(prev => [...prev, newExpense])
      setCustomName('')
      setShowCustom(false)
    }
  }

  const removeExpense = (id: string) => {
    setExpenses(prev => prev.filter(exp => exp.id !== id))
  }

  const selectedExpenses = expenses.filter(exp => exp.selected)
  const totalFixed = selectedExpenses.reduce((sum, exp) => sum + exp.amount, 0)

  const handleSubmit = () => {
    onNext(selectedExpenses)
  }

  return (
    <div className="min-h-screen bg-background flex flex-col p-6">
      {/* Progress indicator */}
      <div className="flex gap-2 mb-8">
        <div className="h-1 flex-1 bg-primary rounded"></div>
        <div className="h-1 flex-1 bg-primary rounded"></div>
        <div className="h-1 flex-1 bg-primary rounded"></div>
        <div className="h-1 flex-1 bg-gray-700 rounded"></div>
      </div>

      {/* Back button */}
      <button onClick={onBack} className="text-gray-400 text-sm mb-6">
        ← Volver
      </button>

      {/* Question */}
      <h2 className="text-2xl font-bold text-white mb-2">
        ¿Qué gastos fijos tienes? 📋
      </h2>
      <p className="text-gray-400 mb-6">
        Elige los que apliquen y pon cuánto pagas
      </p>

      {/* Expenses list */}
      <div className="flex-1 overflow-y-auto space-y-3 mb-4">
        {expenses.map((expense) => (
          <div
            key={expense.id}
            className={`bg-background-card rounded-xl p-4 transition-all ${
              expense.selected ? 'border-2 border-primary' : 'border-2 border-transparent'
            }`}
          >
            <div className="flex items-center gap-3">
              {/* Checkbox area */}
              <button
                onClick={() => toggleExpense(expense.id)}
                className={`w-10 h-10 rounded-lg flex items-center justify-center transition-colors ${
                  expense.selected
                    ? 'bg-primary text-white'
                    : 'bg-background-light text-gray-400'
                }`}
              >
                {iconMap[expense.icon]}
              </button>

              {/* Name */}
              <span className="flex-1 text-white">{expense.name}</span>

              {/* Remove custom */}
              {expense.id.startsWith('custom-') && (
                <button
                  onClick={() => removeExpense(expense.id)}
                  className="text-gray-500 hover:text-red-400"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Amount input (only when selected) */}
            {expense.selected && (
              <div className="mt-3 relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">$</span>
                <input
                  type="text"
                  inputMode="numeric"
                  value={expense.amount > 0 ? formatMoney(expense.amount.toString()) : ''}
                  onChange={(e) => updateAmount(expense.id, e.target.value)}
                  placeholder="Monto mensual"
                  className="w-full bg-background border border-gray-700 rounded-lg py-2 pl-8 pr-3 text-white outline-none focus:border-primary"
                />
              </div>
            )}
          </div>
        ))}

        {/* Add custom expense */}
        {showCustom ? (
          <div className="bg-background-card rounded-xl p-4">
            <input
              type="text"
              value={customName}
              onChange={(e) => setCustomName(e.target.value)}
              placeholder="Nombre del gasto..."
              className="w-full bg-background border border-gray-700 rounded-lg py-2 px-3 text-white outline-none focus:border-primary mb-2"
              autoFocus
            />
            <div className="flex gap-2">
              <button
                onClick={addCustomExpense}
                className="flex-1 bg-primary text-white py-2 rounded-lg text-sm"
              >
                Agregar
              </button>
              <button
                onClick={() => setShowCustom(false)}
                className="flex-1 bg-gray-700 text-white py-2 rounded-lg text-sm"
              >
                Cancelar
              </button>
            </div>
          </div>
        ) : (
          <button
            onClick={() => setShowCustom(true)}
            className="w-full bg-background-card border-2 border-dashed border-gray-700 rounded-xl p-4 text-gray-400 hover:border-primary hover:text-primary transition-colors flex items-center justify-center gap-2"
          >
            <Plus className="w-5 h-5" />
            Agregar otro gasto fijo
          </button>
        )}
      </div>

      {/* Summary */}
      <div className="bg-background-card rounded-xl p-4 mb-4">
        <div className="flex justify-between items-center">
          <span className="text-gray-400">Total gastos fijos:</span>
          <span className="text-xl font-bold text-white">
            ${totalFixed.toLocaleString('es-CO')}
          </span>
        </div>
      </div>

      {/* CTA */}
      <button
        onClick={handleSubmit}
        className="w-full bg-primary hover:bg-primary-dark text-white font-semibold py-4 rounded-xl transition-all duration-200"
      >
        Ver cuánto me queda →
      </button>
    </div>
  )
}
