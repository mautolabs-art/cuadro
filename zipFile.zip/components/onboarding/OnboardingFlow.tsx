'use client'

import { useState } from 'react'
import Step1Welcome from './Step1Welcome'
import Step2Income from './Step2Income'
import Step3FixedExpenses from './Step3FixedExpenses'
import Step4Revelation from './Step4Revelation'

interface FixedExpense {
  id: string
  name: string
  icon: string
  amount: number
  selected: boolean
}

interface UserData {
  income: number
  fixedExpenses: FixedExpense[]
}

interface Props {
  onComplete: (data: UserData) => void
}

export default function OnboardingFlow({ onComplete }: Props) {
  const [step, setStep] = useState(1)
  const [income, setIncome] = useState(0)
  const [fixedExpenses, setFixedExpenses] = useState<FixedExpense[]>([])

  const handleIncomeSubmit = (value: number) => {
    setIncome(value)
    setStep(3)
  }

  const handleExpensesSubmit = (expenses: FixedExpense[]) => {
    setFixedExpenses(expenses)
    setStep(4)
  }

  const handleComplete = () => {
    onComplete({ income, fixedExpenses })
  }

  return (
    <div className="min-h-screen">
      {step === 1 && (
        <Step1Welcome onNext={() => setStep(2)} />
      )}
      {step === 2 && (
        <Step2Income
          onNext={handleIncomeSubmit}
          onBack={() => setStep(1)}
        />
      )}
      {step === 3 && (
        <Step3FixedExpenses
          onNext={handleExpensesSubmit}
          onBack={() => setStep(2)}
        />
      )}
      {step === 4 && (
        <Step4Revelation
          income={income}
          fixedExpenses={fixedExpenses}
          onComplete={handleComplete}
        />
      )}
    </div>
  )
}
